import React from 'react';
import FarmerRegistrationForm from './pages/farmerregistration/farmerregistration';
import NutritionForm from './pages/Nutrition/nutrition';
import FarmHousing from './pages/farmhousing/farmhousing'

function App() {
  return (
    <div className="App">
      <FarmHousing/>
    </div>
  );
}

export default App;
